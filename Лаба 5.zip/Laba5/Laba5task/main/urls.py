from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('postavte5', views.postavte5),
]
