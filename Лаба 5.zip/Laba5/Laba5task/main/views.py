from django.shortcuts import render
from .models import Test

def index(res):
    return render(res, 'main/index.html')

def postavte5(res):
    tasks = Test.objects.all()
    return render(res, 'main/postavte5.html', {'title': 'Main Page', 'tasks' : tasks})

