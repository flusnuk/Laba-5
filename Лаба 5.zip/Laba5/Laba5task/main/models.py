from django.db import models

class Test(models.Model):
   title = models.CharField("Nazva", max_length=50)
   task = models.TextField("Describe")
